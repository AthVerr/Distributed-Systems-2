/**
 *Athina Verroiopoulou
 *1/9/2017
 *CSC435, InetServer
 */

import java.net.ServerSocket;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 
 * With the use of a thread we can have multiple processes that are executed at the same time in one (beginning) process
 * threads share the same space to save the address, so they can access the same object in a program
 */
class Worker extends Thread {
	Socket sock; //Create a local Socket value "sock" 
	//create the socket for communication, act as a constructor 
	Worker(Socket s) {
		sock = s; //pass s as a socket parameter and assign it to sock 
	} 
	public void run() {
		PrintStream out = null; //initialize the out value
		BufferedReader in = null; //initialize the out value
		try {
			/**
			 * BufferedReader is used to read text from a character input stream, it buffers characters.
			 * In Java Sockets every program can read and write in a Socket with the use of Input and OutputStream 
			 * that is a similar procedure with files. */
			in = new BufferedReader(new InputStreamReader(sock.getInputStream())); //read from client , connect with socket
			out = new PrintStream(sock.getOutputStream()); //write/respond to the client, connect with socket , for messages 
			try {
				String name;//save the client response 
				name = in.readLine(); //read from the client the hostname or IP that is send with 
				System.out.println("Looking up " + name); //message with the hostname or IP 
				printRemoteAddress(name, out); //call the method printRemoteAddress and pass the given name and the Output object
			} catch (IOException x) {
				System.out.println("Server read error");//in case of error in connection
				x.printStackTrace();
			}
			sock.close(); //we call the close method of Java.net.Socket class to terminate the connection with the specific client, not the server
		} catch (IOException ioe) {//in case of error in reading
			System.out.println(ioe);
		}
	}
//send remote address to client 
	static void printRemoteAddress(String name, PrintStream out) {//take the parameters for hostname or IP and output obj
		try {
			out.println("Looking up: " + name + "...");//sent the message to the client 
			//search by the given name, can be a machine name or text representation 
			InetAddress machine = InetAddress.getByName(name);//make an InetAdress object 
			//based on the IP gives the host name
			out.println("Host name : " + machine.getHostName()); // sent the hostname to client with the exact message
			//used the method toText 
			out.println("Host IP : " + toText(machine.getAddress())); // sent the host IP to client with the exact message 
		} catch (UnknownHostException ex) {
			out.println("Failed in atempt to look up " + name);//try /catch in case the name can not be recognized
		}
	}

	//same method with client 
	static String toText(byte ip[]) { //take as parameter the ip in byte , from -128 and 127
		StringBuffer result = new StringBuffer();//contains a particular sequence of characters 
		for (int i = 0; i < ip.length; ++i) {//the for is until the length of the ip given as a parameter 
			if (i > 0) //if positive
				result.append(".");
			result.append(0xff & ip[i]); //0xff positive int , leave the 8 lower bits, add the ip[i]
		}
		return result.toString(); //return the updated string buffer object
	}
}
/**
 * The server is waiting for incoming connections from clients and uses the class ava.net.ServerSocket
 * */
 
public class InetServer {
	public static void main(String a[]) throws IOException {
		int requests = 8; //number of client requests			
		int port = 5555;//the port that the server is waiting for connection with client
		Socket sock;
		ServerSocket server = new ServerSocket(port, requests);//the socket take as parameter the port and request number and we create an object
		System.out.println("Athinas Inet server 1.8 starting up, listening at port 5555.\n");//print message
		while (true) {
			//the object created from the server socket uses the accept method to block the program running until there is an incoming request
			sock = server.accept(); //can accept 6 clients, returns an object reference to exchange messages with the clients
			new Worker(sock).start(); //start thread and Worker class
		}
	}
}
