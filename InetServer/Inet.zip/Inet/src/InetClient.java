/**
 *Athina Verroiopoulou
 *1/9/2017
 *CSC435, InetClient
 */

import java.io.*;
import java.net.Socket; 

/**
 *The client class is made in order to create a connection with the Server class. 
 *In order to achieve that we need a port and an IP address that will wait for the connection
 *The port and IP values are given as input for the creation of Java.net.Socket class
 */
public class InetClient {
	public static void main(String args[]) {
		String serverName; //we give an IP address or a hostName for our server in a String form
		if (args.length < 1) //in case the length of the given server name is less than one 
			serverName = "localhost"; //the default choice is the local host
		else
			serverName = args[0];// server name is equal with the String value that is given, for my machine "192.168.0.34"
		System.out.println("Athina's Inet Client, 1.8.\n");//print the message
		System.out.println("Using server: " + serverName + ", Port: 5555");//print the Server name(hostname or IP address) and the using port

		/**
		 * BufferedReader is used to read text from a character input stream, it buffers characters.
		 * In Java Sockets every program can read and write in a Socket with the use of Input and OutputStream 
		 * that is a similar procedure with files. It represents an input stream of bytes and is used for the client / server connection. 
		 * We use InputStreamReader(System.in) to pass simple messages to server. For objects we should use ObjectInputStream / ObjectOutputStream
		 **/
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));//read from Socket
		//BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out)); ( write )
		try {
			String name=null;//a string that is used to save host name or IP  that is read
			do {
				System.out.print("Enter a hostname or an IP address, (quit) to end: ");//print the message
				System.out.flush();//is used to empty the memory from every byte that is written in the buffer
				name = in.readLine();//reads the host name or IP , in client, is given "192.168.0.34"
				if (name.indexOf("quit") < 0)//if the response  doen't return a word with "quit"
					getRemoteAddress(name, serverName); //call the getRemoteAddress method that take for parameter the port and IP address 
			} while (name.indexOf("quit") < 0); // this will run until the user give an exit message , a word with "quit " inside
			System.out.println("Cancelled by user request.");//print exit message
		} catch (IOException x) {
			x.printStackTrace();
		}
	}
//is  used to produce a portable format for 128 bit
	static String toText(byte ip[]) { //take as parameter the ip in byte , from -128 and 127
		StringBuffer result = new StringBuffer();//contains a particular sequence of characters 
		for (int i = 0; i < ip.length; ++i) {//the for is until the length of the ip given as a parameter 
			if (i > 0)//if positive
				//in the ip "192.168.0.34" add the "."
				result.append(".");
			result.append(0xff & ip[i]); //0xff positive int , leave the 8 lower bits, add the ip[i]
		}
		return result.toString();//return the updated string buffer object
	}
//this method is called from the main to get the remote address from server
	static void getRemoteAddress(String name, String serverName) {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer; //a string to save server answer 
		try {
			sock = new Socket(serverName, 5555); //connection with server
			fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));//read from the server, connect with socket
			toServer = new PrintStream(sock.getOutputStream());//write / send to server, connect with socket
			//The server is waiting for client response, the client will send the name of the host name or IP 
			toServer.println(name); //in this method the client will send to server the name that is passed as a parameter in getRemoteAddress(String name)
			toServer.flush();//clean the memory
			//if its not empty we will have 3 responses from server, one by one 
			//they should be:
			//Looking up:  name ...
			//Host name : hostname
			//Host IP : host ip			
			for (int i = 1; i <= 3; i++) {//will read 3 times
				textFromServer = fromServer.readLine();//the client reads the server message and save it in textFromServer
				if (textFromServer != null)//if the server answer is not empty
					System.out.println(textFromServer);//print server message
			}
			sock.close(); //we call the close method of Java.net.Socket class to terminate the connection
		} catch (IOException x) {
			System.out.println("Socket error.");//the try catch is used to identify connection errors 
			x.printStackTrace();
		}
	}
}